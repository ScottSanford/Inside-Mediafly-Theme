$(document).ready(function(){

	document.addEventListener('touchmove', function(event) {
    	event.preventDefault();
    }, false);

    $(function() {
    	FastClick.attach(document.body);
	});

	$("#menu").mmenu();


	$('.menu-edit, .menu-save, .menu-load, .menu-close').bind("touchend click" , function(){
		$('#menu').trigger('close.mm');
	})

	$('.menu-close').bind('touchend click', function(){
		mflyCommands.close();
	})


	$('.annotations').bind("touchend click" , function(){
		// mflyCommands.showAnnotations(500,500,500,500);
		$('#menu').trigger('close.mm');
		
		var clicked = true;		
		if (clicked) {
			var timesRun = 0;
			var interval = setInterval(function(){
				timesRun += 1;
				mflyCommands.showAnnotations(500,500,500,500);
				if (timesRun  === 1) {
					clearInterval(interval);
				}
			}, 500);
		}
	})

	$('.second-screen').bind("touchend click" , function(){
		$('#menu').trigger("close.mm");
		mflyCommands.showSecondScreen();
	})

	$('.collections').bind("touchend click" , function(){
		$('#menu').trigger("close.mm");
		mflyCommands.showAddToCollection("f7e484d0e3ee4e87901ee34fe2fcbe1aproduct154902", 1, 1, 1, 1);
	})

	$('.email').bind("touchend click" , function(){
		$('#menu').trigger("close.mm");
		mflyCommands.email("f7e484d0e3ee4e87901ee34fe2fcbe1aproduct154902");
	})

	$('.previous').bind("touchend click", function(){
		mflyCommands.previous();
	})

	$('.next').bind("touchend click", function(){
		mflyCommands.next();
	})

	$('.close-btn').bind("touchend click" , function(){
		$('#menu').trigger("close.mm");
		console.log('closed');
		mflyCommands.close();
	})

});