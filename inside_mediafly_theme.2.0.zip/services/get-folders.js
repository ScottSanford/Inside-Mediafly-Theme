angular.module('imApp')

.factory("getFolderService", function($http, $q) {
    return function() {
        console.log('Service is connected!');
        var deferred = $q.defer();

        mflyCommands.search('@Featured')
            .done(function(data) {
                console.log(data);
                for (var i = 0; i < data.length; i++) {
                    var featuredId = data[i]["id"];
                    mflyCommands.openFolder(featuredId);
                    console.log(featuredId);          
                }
            })
    return deferred.promise;
    }
});