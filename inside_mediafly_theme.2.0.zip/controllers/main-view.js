angular.module('imApp')

	.controller('mainViewCtrl', function($scope){

		mflyCommands.search('@Featured')
			.done(function(data){
				$scope.featured = data;
			})		

		mflyCommands.search('@TopLevelSales')
			.done(function(data){
				$scope.topLevelSales = data;
			})

		$scope.openFolder = function(id) {
			mflyCommands.openFolder(id);
		}

		$scope.taglineImage = 'images/inside_mediafly_logo.png';
	});